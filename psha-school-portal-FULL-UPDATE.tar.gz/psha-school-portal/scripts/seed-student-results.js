'use strict';

/**
 * Populate student results (CA / Test / Exam) for demo or testing.
 *
 * Usage:
 *   node scripts/seed-student-results.js
 *   node scripts/seed-student-results.js --student STU-2025-001
 *   node scripts/seed-student-results.js --all --status published
 *   node scripts/seed-student-results.js --class "JSS 1A"
 *
 * Requires DATABASE_* in .env. Uses current session + term when available.
 */

require('dotenv').config({ path: require('path').join(__dirname, '..', '.env') });

const mysql = require('mysql2/promise');

const args = process.argv.slice(2);
function flag(name) {
  const i = args.indexOf(name);
  if (i === -1) return null;
  return args[i + 1] && !args[i + 1].startsWith('--') ? args[i + 1] : true;
}

const ONLY_STUDENT = flag('--student'); // student_id string e.g. STU-2025-001
const ONLY_CLASS = flag('--class'); // class name fragment
const STATUS = typeof flag('--status') === 'string' ? flag('--status') : 'published';
const FORCE = args.includes('--force'); // overwrite existing non-published; skip published unless force

function rand(min, max) {
  return Math.round((min + Math.random() * (max - min)) * 100) / 100;
}

function gradeFromScore(score, boundaries) {
  if (score == null || !boundaries.length) return null;
  const s = Number(score);
  for (const b of boundaries) {
    if (s >= Number(b.min_score) && s <= Number(b.max_score)) {
      return b.grade_label;
    }
  }
  // fallback open ends
  const sorted = [...boundaries].sort((a, b) => Number(b.min_score) - Number(a.min_score));
  for (const b of sorted) {
    if (s >= Number(b.min_score)) return b.grade_label;
  }
  return sorted[sorted.length - 1]?.grade_label || 'F';
}

function remarkFromScore(score) {
  const s = Number(score);
  if (s >= 70) return 'Excellent performance. Keep it up.';
  if (s >= 60) return 'Very good work. Aim higher next term.';
  if (s >= 50) return 'Good effort. More consistency needed.';
  if (s >= 40) return 'Fair. Extra practice recommended.';
  return 'Needs improvement. Please seek support.';
}

async function main() {
  if (!process.env.DATABASE_USER || !process.env.DATABASE_NAME) {
    console.error('DATABASE_USER and DATABASE_NAME must be set in .env');
    process.exit(1);
  }

  const conn = await mysql.createConnection({
    host: process.env.DATABASE_HOST || '127.0.0.1',
    port: Number(process.env.DATABASE_PORT) || 3306,
    user: process.env.DATABASE_USER,
    password: process.env.DATABASE_PASSWORD,
    database: process.env.DATABASE_NAME,
    namedPlaceholders: true
  });

  const q = async (sql, params = {}) => {
    const [rows] = await conn.execute(sql, params);
    return rows;
  };

  try {
    // Session
    let sessions = await q(
      `SELECT id, name FROM academic_sessions WHERE is_current = 1 ORDER BY id DESC LIMIT 1`
    );
    if (!sessions.length) {
      sessions = await q(`SELECT id, name FROM academic_sessions ORDER BY id DESC LIMIT 1`);
    }
    if (!sessions.length) {
      console.error('No academic session found. Run npm run seed first.');
      process.exit(1);
    }
    const session = sessions[0];

    // Term
    let terms = await q(
      `SELECT id, name FROM terms WHERE academic_session_id = :sid AND is_current = 1 LIMIT 1`,
      { sid: session.id }
    );
    if (!terms.length) {
      terms = await q(
        `SELECT id, name FROM terms WHERE academic_session_id = :sid ORDER BY id ASC LIMIT 1`,
        { sid: session.id }
      );
    }
    if (!terms.length) {
      // any term
      terms = await q(`SELECT id, name FROM terms ORDER BY id DESC LIMIT 1`);
    }
    if (!terms.length) {
      console.error('No term found. Run npm run seed first.');
      process.exit(1);
    }
    const term = terms[0];

    // Grading
    let gs = await q(`SELECT id FROM grading_systems WHERE is_default = 1 LIMIT 1`);
    if (!gs.length) gs = await q(`SELECT id FROM grading_systems ORDER BY id LIMIT 1`);
    let boundaries = [];
    if (gs.length) {
      boundaries = await q(
        `SELECT grade_label, min_score, max_score FROM grade_boundaries
         WHERE grading_system_id = :id ORDER BY min_score DESC`,
        { id: gs[0].id }
      );
    }
    if (!boundaries.length) {
      boundaries = [
        { grade_label: 'A', min_score: 70, max_score: 100 },
        { grade_label: 'B', min_score: 60, max_score: 69.99 },
        { grade_label: 'C', min_score: 50, max_score: 59.99 },
        { grade_label: 'D', min_score: 45, max_score: 49.99 },
        { grade_label: 'E', min_score: 40, max_score: 44.99 },
        { grade_label: 'F', min_score: 0, max_score: 39.99 }
      ];
    }

    // Students
    let studentSql = `
      SELECT s.id, s.student_id, s.first_name, s.last_name, s.class_id, c.name AS class_name
      FROM students s
      LEFT JOIN classes c ON c.id = s.class_id
      WHERE s.status = 'active' AND s.class_id IS NOT NULL
    `;
    const studentParams = {};
    if (ONLY_STUDENT && ONLY_STUDENT !== true) {
      studentSql += ` AND s.student_id = :sid`;
      studentParams.sid = ONLY_STUDENT;
    }
    if (ONLY_CLASS && ONLY_CLASS !== true) {
      studentSql += ` AND c.name LIKE :cname`;
      studentParams.cname = `%${ONLY_CLASS}%`;
    }
    studentSql += ` ORDER BY s.id`;
    const students = await q(studentSql, studentParams);

    if (!students.length) {
      console.error('No matching students with a class. Seed users or pass a valid --student id.');
      process.exit(1);
    }

    // Subjects (prefer those linked to class via class_subjects if table exists)
    let subjects = [];
    try {
      subjects = await q(
        `SELECT DISTINCT sub.id, sub.name, sub.code
         FROM subjects sub
         INNER JOIN class_subjects cs ON cs.subject_id = sub.id
         WHERE cs.class_id IN (${students.map((s) => s.class_id).join(',') || '0'})
         ORDER BY sub.name
         LIMIT 12`
      );
    } catch {
      subjects = [];
    }
    if (!subjects.length) {
      subjects = await q(
        `SELECT id, name, code FROM subjects WHERE is_active = 1 OR is_active IS NULL ORDER BY id LIMIT 8`
      );
    }
    if (!subjects.length) {
      subjects = await q(`SELECT id, name, code FROM subjects ORDER BY id LIMIT 8`);
    }
    if (!subjects.length) {
      console.error('No subjects found. Run npm run seed first.');
      process.exit(1);
    }

    console.log(`Session: ${session.name} (id=${session.id})`);
    console.log(`Term:    ${term.name} (id=${term.id})`);
    console.log(`Students: ${students.length}`);
    console.log(`Subjects: ${subjects.map((s) => s.name).join(', ')}`);
    console.log(`Status:  ${STATUS}`);
    console.log('');

    // Weights: CA 30, Test 20, Exam 50
    const WEIGHTS = [
      { name: 'CA', max: 30, weight: 30 },
      { name: 'Test', max: 20, weight: 20 },
      { name: 'Exam', max: 50, weight: 50 }
    ];

    let created = 0;
    let updated = 0;
    let skipped = 0;

    for (const student of students) {
      for (const subject of subjects) {
        const existing = await q(
          `SELECT id, status FROM results
           WHERE student_id = :studentId AND class_id = :classId
             AND subject_id = :subjectId AND term_id = :termId
             AND academic_session_id = :sessionId
           LIMIT 1`,
          {
            studentId: student.id,
            classId: student.class_id,
            subjectId: subject.id,
            termId: term.id,
            sessionId: session.id
          }
        );

        if (existing.length && existing[0].status === 'published' && !FORCE) {
          skipped += 1;
          continue;
        }

        // Random but realistic component scores
        const ca = rand(WEIGHTS[0].max * 0.45, WEIGHTS[0].max * 0.98);
        const test = rand(WEIGHTS[1].max * 0.4, WEIGHTS[1].max * 0.98);
        const exam = rand(WEIGHTS[2].max * 0.4, WEIGHTS[2].max * 0.98);
        const scores = [ca, test, exam];
        const total = Math.round((ca + test + exam) * 100) / 100;
        const grade = gradeFromScore(total, boundaries);
        const comment = remarkFromScore(total);

        const components = WEIGHTS.map((w, i) => ({
          name: w.name,
          score: scores[i],
          maxScore: w.max,
          weight: w.weight
        }));

        if (existing.length) {
          const id = existing[0].id;
          await q(
            `UPDATE results
             SET total_score = :total, grade = :grade, teacher_comment = :comment,
                 status = :status,
                 published_at = IF(:status = 'published', COALESCE(published_at, NOW()), published_at),
                 updated_at = NOW()
             WHERE id = :id`,
            { id, total, grade, comment, status: STATUS }
          );
          await q(`DELETE FROM result_components WHERE result_id = :id`, { id });
          for (const c of components) {
            await q(
              `INSERT INTO result_components (result_id, component_name, score, max_score, weight)
               VALUES (:resultId, :name, :score, :maxScore, :weight)`,
              {
                resultId: id,
                name: c.name,
                score: c.score,
                maxScore: c.maxScore,
                weight: c.weight
              }
            );
          }
          updated += 1;
        } else {
          const ins = await q(
            `INSERT INTO results
               (student_id, class_id, subject_id, academic_session_id, term_id,
                total_score, grade, teacher_comment, status, published_at)
             VALUES
               (:studentId, :classId, :subjectId, :sessionId, :termId,
                :total, :grade, :comment, :status,
                IF(:status = 'published', NOW(), NULL))`,
            {
              studentId: student.id,
              classId: student.class_id,
              subjectId: subject.id,
              sessionId: session.id,
              termId: term.id,
              total,
              grade,
              comment,
              status: STATUS
            }
          );
          const resultId = ins.insertId;
          for (const c of components) {
            await q(
              `INSERT INTO result_components (result_id, component_name, score, max_score, weight)
               VALUES (:resultId, :name, :score, :maxScore, :weight)`,
              {
                resultId,
                name: c.name,
                score: c.score,
                maxScore: c.maxScore,
                weight: c.weight
              }
            );
          }
          created += 1;
        }
      }
      console.log(
        `  ✓ ${student.student_id} ${student.first_name} ${student.last_name} (${student.class_name || 'no class'})`
      );
    }

    console.log('');
    console.log(`Done. created=${created} updated=${updated} skipped_published=${skipped}`);
    console.log('View as student/parent on Results (published only).');
  } finally {
    await conn.end();
  }
}

main().catch((err) => {
  console.error('Seed results failed:', err.message);
  process.exit(1);
});
