'use strict';

/**
 * Reset a user's password (typically the administrator).
 *
 * Usage:
 *   node scripts/reset-admin-password.js
 *   node scripts/reset-admin-password.js admin@psha.edu.ng 'NewPassword@123'
 *   node scripts/reset-admin-password.js admin@psha.edu.ng 'NewPassword@123' --no-force-change
 *
 * Requires DATABASE_* in .env and a working MySQL connection.
 */

require('dotenv').config({ path: require('path').join(__dirname, '..', '.env') });

const mysql = require('mysql2/promise');
const { hashPassword } = require('../utils/crypto');

const email = process.argv[2] || 'admin@psha.edu.ng';
const newPassword = process.argv[3] || 'Admin@PSHA2026!';
const forceChange = !process.argv.includes('--no-force-change');

async function main() {
  if (!newPassword || newPassword.length < 8) {
    console.error('Password must be at least 8 characters.');
    process.exit(1);
  }

  if (!process.env.DATABASE_USER || !process.env.DATABASE_NAME) {
    console.error('DATABASE_USER and DATABASE_NAME must be set in .env');
    process.exit(1);
  }

  const connection = await mysql.createConnection({
    host: process.env.DATABASE_HOST || '127.0.0.1',
    port: Number(process.env.DATABASE_PORT) || 3306,
    user: process.env.DATABASE_USER,
    password: process.env.DATABASE_PASSWORD,
    database: process.env.DATABASE_NAME,
    namedPlaceholders: true
  });

  try {
    const [rows] = await connection.execute(
      `SELECT u.id, u.email, u.is_active, r.name AS role_name
       FROM users u
       LEFT JOIN roles r ON r.id = u.role_id
       WHERE u.email = :email
       LIMIT 1`,
      { email }
    );

    if (!rows.length) {
      console.error(`No user found with email: ${email}`);
      process.exit(1);
    }

    const user = rows[0];
    const passwordHash = await hashPassword(newPassword);

    // Only columns that exist in core schema
    await connection.execute(
      `UPDATE users
       SET password_hash = :password_hash,
           must_change_password = :must_change,
           updated_at = CURRENT_TIMESTAMP
       WHERE id = :id`,
      {
        password_hash: passwordHash,
        must_change: forceChange ? 1 : 0,
        id: user.id
      }
    );

    console.log('Password reset successful.');
    console.log(`  Email:    ${user.email}`);
    console.log(`  Role:     ${user.role_name || 'unknown'}`);
    console.log(`  Active:   ${user.is_active ? 'yes' : 'no'}`);
    console.log(`  Password: ${newPassword}`);
    if (forceChange) {
      console.log('  Note: must_change_password = 1 (asked to change on next login)');
      console.log('  Tip:  add --no-force-change to use this password without forced change');
    } else {
      console.log('  Note: must_change_password = 0 (login with this password immediately)');
    }
  } finally {
    await connection.end();
  }
}

main().catch((err) => {
  console.error('Reset failed:', err.message);
  if (err.code === 'ER_ACCESS_DENIED_ERROR') {
    console.error('Check DATABASE_USER / DATABASE_PASSWORD in .env');
  }
  process.exit(1);
});
